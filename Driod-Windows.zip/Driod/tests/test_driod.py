import json
import math
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request
from unittest.mock import patch

from driod.agent import Agent, redact
from driod.extras import Extras, indicators
from driod.provider import OpenRouter, ProviderError
from driod.tools import Toolbox
from driod.voice import wake_command
from driod.workspace import Workspace


class Base(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.base = Path(self.temp.name)
        self.ws = Workspace(self.base / "projects", self.base / "state")
        self.events, self.requests = [], []
        self.approved = True
        def approve(title, body):
            self.requests.append((title, body))
            return self.approved
        self.stop = threading.Event()
        self.box = Toolbox(self.ws, approve, lambda *e: self.events.append(e), self.stop)
        self.extras = Extras(self.box)
        self.box.extra = self.extras

    def tearDown(self):
        self.box.close()
        self.temp.cleanup()


class FileTests(Base):
    def test_write_read_backup_restore(self):
        self.ws.write_file("shop/index.html", "Before")
        change = self.ws.write_file("shop/index.html", "After")
        self.assertEqual(self.ws.read_file("shop/index.html")["content"], "After")
        self.assertEqual(len(self.ws.list_backups("shop/index.html")["backups"]), 1)
        self.box.execute("restore_file", {"backup_id": change["backup_id"]})
        self.assertEqual(self.ws.read_file("shop/index.html")["content"], "Before")
        self.assertTrue(self.requests)

    def test_external_edit_conflict(self):
        self.ws.write_file("a.txt", "one")
        self.ws.path("a.txt").write_text("user edit")
        with self.assertRaises(ValueError):
            self.ws.write_file("a.txt", "two")
        self.assertEqual(self.ws.path("a.txt").read_text(), "user edit")

    def test_existing_file_requires_read(self):
        self.ws.path("a.txt").write_text("handwritten")
        with self.assertRaises(ValueError):
            self.ws.write_file("a.txt", "AI edit")
        self.ws.read_file("a.txt")
        self.ws.write_file("a.txt", "AI edit")

    def test_invalid_paths(self):
        for path in ["../outside.txt", "/tmp/file", "C:\\Windows\\file", "a/../../b", ".env", "a/.git/config", "file:secret", "CON", "aux.txt", "bad. ", "credentials.json"]:
            with self.subTest(path=path), self.assertRaises(ValueError):
                self.ws.path(path)

    def test_symlink_escape(self):
        outside = self.base / "outside"
        outside.mkdir()
        try:
            (self.ws.root / "link").symlink_to(outside, target_is_directory=True)
        except OSError:
            self.skipTest("Symlinks unavailable")
        with self.assertRaises(ValueError):
            self.ws.write_file("link/oops.txt", "bad")

    def test_unique_replace_and_rename(self):
        self.ws.write_file("a.txt", "one two one")
        with self.assertRaises(ValueError):
            self.ws.replace_text("a.txt", "one", "three")
        self.ws.replace_text("a.txt", "two", "three")
        self.ws.rename_file("a.txt", "folder/b.txt")
        self.assertEqual(self.ws.read_file("folder/b.txt")["content"], "one three one")

    def test_import_preserves_existing(self):
        original = self.base / "photo.png"
        original.write_bytes(b"test binary")
        first = self.ws.import_file(original)
        second = self.ws.import_file(original)
        self.assertNotEqual(first, second)
        self.assertEqual(self.ws.path(first).read_bytes(), b"test binary")

    def test_declined_restore_does_not_write(self):
        self.ws.write_file("a.txt", "one")
        backup = self.ws.write_file("a.txt", "two")["backup_id"]
        self.approved = False
        result = self.box.execute("restore_file", {"backup_id": backup})
        self.assertIn("declined", result["error"])
        self.assertEqual(self.ws.read_file("a.txt")["content"], "two")


class ToolTests(Base):
    def command(self, code):
        if os.name == "nt":
            return "& '" + sys.executable.replace("'", "''") + "' -c '" + code.replace("'", "''") + "'"
        import shlex
        return shlex.quote(sys.executable) + " -c " + shlex.quote(code)

    def test_command_output_and_exit(self):
        result = self.box.run_command(self.command('print("check passed")'))
        self.assertEqual(result["exit_code"], 0)
        self.assertIn("check passed", result["output"])
        self.assertTrue(self.requests)

    def test_declined_command_no_side_effect(self):
        self.approved = False
        result = self.box.execute("run_command", {"command": self.command('open("bad.txt","w").write("bad")')})
        self.assertIn("declined", result["error"])
        self.assertFalse(self.ws.path("bad.txt").exists())

    def test_timeout_stops_process(self):
        result = self.box.run_command(self.command("import time; time.sleep(20)"), timeout=1)
        self.assertEqual(result["interrupted"], "Timed out")

    def test_stop_cancels_running_command(self):
        timer = threading.Timer(.3, self.stop.set)
        timer.start()
        result = self.box.run_command(self.command("import time; time.sleep(20)"))
        timer.join()
        self.assertEqual(result["interrupted"], "Stopped by user")

    def test_preview_serves_project_and_blocks_hidden(self):
        self.ws.write_file("store/index.html", "<h1>Preview works</h1>")
        (self.ws.root / "store" / ".env").write_text("SECRET")
        url = self.box.start_preview("store")["url"]
        with urllib.request.urlopen(url) as r:
            self.assertIn("Preview works", r.read().decode())
        for suffix in [".env", "%2eenv", "../.env"]:
            with self.assertRaises(urllib.error.HTTPError):
                urllib.request.urlopen(url + suffix)

    def test_unknown_tool_and_bad_args(self):
        self.assertIn("error", self.box.execute("delete_everything", {}))
        self.assertIn("error", self.box.execute("write_file", {"unknown": 5}))

    def test_background_process_lifecycle(self):
        ident = self.box.start_process(self.command('import time; print("started",flush=True); time.sleep(20)'))["process_id"]
        for _ in range(30):
            data = self.box.process_status(ident)
            if "started" in data["output"]:
                break
            time.sleep(.05)
        self.assertIn("started", data["output"])
        self.assertTrue(data["running"])
        self.box.stop_process(ident)
        self.assertFalse(self.box.process_status(ident)["running"])


def tool_call(identifier, name, args):
    return {"id": identifier, "type": "function", "function": {"name": name, "arguments": json.dumps(args)}}


class AgentTests(Base):
    def test_iterative_repair_with_tool_results(self):
        class Fake:
            key = "test-key-never-log"
            step = 0
            def complete(inner, messages, schemas):
                inner.step += 1
                if inner.step == 1:
                    return {"role": "assistant", "tool_calls": [tool_call("1", "write_file", {"path": "main.js", "content": "broken"})]}, {}
                if inner.step == 2:
                    self.assertEqual(messages[-1]["tool_call_id"], "1")
                    return {"role": "assistant", "tool_calls": [tool_call("2", "read_file", {"path": "main.js"}), tool_call("3", "replace_text", {"path": "main.js", "old": "broken", "new": "console.log('fixed');"})]}, {}
                self.assertEqual(messages[-1]["tool_call_id"], "3")
                return {"role": "assistant", "content": "File repaired."}, {}
        agent = Agent(Fake(), self.box, lambda *e: self.events.append(e))
        agent.run("Create and repair a file")
        self.assertEqual(self.ws.read_file("main.js")["content"], "console.log('fixed');")
        self.assertIn(("answer", "File repaired."), self.events)
        records = [json.loads(x) for x in agent.audit_path.read_text().splitlines()]
        self.assertEqual(len([r for r in records if r["event"] == "tool_request"]), 3)

    def test_malformed_tool_json_is_returned_to_model(self):
        class Fake:
            key = "secret"
            step = 0
            def complete(inner, messages, schemas):
                inner.step += 1
                if inner.step == 1:
                    return {"role": "assistant", "tool_calls": [{"id": "bad", "type": "function", "function": {"name": "write_file", "arguments": "{broken"}}]}, {}
                self.assertIn("Invalid tool JSON", messages[-1]["content"])
                return {"role": "assistant", "content": "Recovered."}, {}
        Agent(Fake(), self.box, lambda *e: self.events.append(e)).run("test")
        self.assertIn(("answer", "Recovered."), self.events)

    def test_credential_redaction(self):
        secret = "my-sensitive-value"
        output = redact(f"{secret} Bearer abc123 api_key=abc123 sk-or-v1-1234567890", [secret])
        for forbidden in [secret, "abc123", "sk-or-v1"]:
            self.assertNotIn(forbidden, output)

    def test_provider_uses_chat_completions_and_preserves_signatures(self):
        provider = OpenRouter("fake", "model")
        message = {"role": "assistant", "content": None, "tool_calls": [], "reasoning_details": [{"signature": "keep"}]}
        with patch.object(provider, "request", return_value={"choices": [{"message": message, "finish_reason": "stop"}]}) as request:
            result, _ = provider.complete([], self.box.schemas)
            endpoint, payload = request.call_args.args
            self.assertEqual(endpoint, "/chat/completions")
            self.assertNotIn("previous_response_id", payload)
            self.assertIn("reasoning_details", result)
            self.assertTrue(payload["tools"])

    def test_truncated_model_output_never_executes(self):
        provider = OpenRouter("fake", "model")
        with patch.object(provider, "request", return_value={"choices": [{"finish_reason": "length"}]}):
            with self.assertRaises(ProviderError):
                provider.complete([], [])


class ExtraTests(Base):
    def test_wake_word_parsing(self):
        self.assertEqual(wake_command("Jarvis open calculator"), "open calculator")
        self.assertEqual(wake_command("hey jarvis create a website"), "create a website")
        self.assertEqual(wake_command("Jarvis"), "")
        self.assertIsNone(wake_command("some random conversation"))
        self.assertEqual(wake_command("open calculator", armed=True), "open calculator")

    def test_finance_indicators(self):
        up = indicators(list(range(1, 101)))
        self.assertEqual(up["SMA20"], 90.5)
        self.assertEqual(up["SMA50"], 75.5)
        self.assertEqual(up["RSI14_Wilder"], 100)
        self.assertGreater(up["MACD_12_26"], 0)
        flat = indicators([10] * 100)
        self.assertEqual(flat["MACD_12_26"], 0)
        self.assertEqual(flat["RSI14_Wilder"], 50)
        down = indicators(list(range(100, 0, -1)))
        self.assertEqual(down["RSI14_Wilder"], 0)

    def test_todos_and_reminders_persist(self):
        item = self.extras.todo("add", "Check website")["todos"][0]
        self.extras.todo("complete", item_id=item["id"])
        self.assertTrue(self.extras.todo("list")["todos"][0]["done"])
        self.extras.reminder("set", "Break", delay_minutes=.001)
        time.sleep(.08)
        self.assertEqual(self.extras.due_reminders()[0]["text"], "Break")
        self.assertEqual(self.extras.due_reminders(), [])

    def test_portfolio_is_storage_not_trading(self):
        self.extras.portfolio("set", "RELIANCE.NS", quantity=2, cost_basis=1200, above=1500)
        data = self.extras.portfolio("list")["holdings"][0]
        self.assertEqual(data["quantity"], 2)
        self.assertEqual(data["above"], 1500)
        with self.assertRaises(ValueError):
            self.extras.portfolio("set", "AAPL", quantity=float("nan"))

    def test_calendar_and_email_are_local_files(self):
        self.extras.create_document("meeting.ics", "calendar", {"title": "Review", "start": "2026-09-27T15:00:00+05:30", "end": "2026-09-27T16:00:00+05:30"})
        self.assertIn("DTSTART:20260927T093000Z", self.ws.path("meeting.ics").read_text())
        self.extras.create_document("draft.eml", "email", {"to": "person@example.com", "subject": "Review", "body": "Hello"})
        self.assertIn("X-Unsent: 1", self.ws.path("draft.eml").read_text())

    def test_office_files_round_trip(self):
        try:
            from docx import Document
            from openpyxl import load_workbook
            from pptx import Presentation
        except ImportError:
            self.skipTest("Office dependencies not installed")
        self.extras.create_document("notes.docx", "docx", {"title": "Notes", "paragraphs": ["Verified paragraph"]})
        self.assertEqual(Document(self.ws.path("notes.docx")).paragraphs[-1].text, "Verified paragraph")
        self.extras.create_document("data.xlsx", "xlsx", {"rows": [["Item", "Quantity"], ["A", 3]]})
        self.assertEqual(load_workbook(self.ws.path("data.xlsx")).active["B2"].value, 3)
        self.extras.create_document("slides.pptx", "pptx", {"title": "Demo", "slides": [{"title": "Result", "bullets": ["Verified"]}]})
        self.assertEqual(len(Presentation(self.ws.path("slides.pptx")).slides), 2)


if __name__ == "__main__":
    unittest.main(verbosity=2)
